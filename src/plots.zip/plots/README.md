## Plots

In this folder it is possible to generate the plots of the paper with the relative Jupyter Notebook.

Inside the folder **csv** are present the zigzag outputs already computed.